# HLP-R Speech Package [![Build Status](https://api.travis-ci.org/HLP-R/hlpr_speech.png)](https://travis-ci.org/HLP-R/hlpr_speech)

All things related to speech. 

Please see the [wiki](https://github.com/HLP-R/hlpr_speech/wiki) to get started.



