#include "ros/ros.h"
#include <stdlib.h>
#include "std_msgs/String.h"
#include "hlpr_speech_msgs/StampedString.h"
#include "geometry_msgs/Twist.h"
#include <turtlesim/Pose.h>

using namespace ros;

std::string command;

void chatterCallback(const hlpr_speech_msgs::StampedString::ConstPtr& msg){
	command = msg->keyphrase.c_str();
}

int main (int argc, char **argv){
	init(argc, argv, "assignment3");
	NodeHandle nh;

	Publisher pub = nh.advertise<geometry_msgs::Twist>("turtle1/cmd_vel", 1000);
	Subscriber sub = nh.subscribe("hlpr_speech_commands", 1000, chatterCallback);

	srand(time(0));
	Rate rate(30);

	geometry_msgs::Twist msg;
	msg.linear.x = 0.0;
	msg.linear.y = 0.0;
	msg.linear.z = 0.0;
	msg.angular.x = 0.0;
	msg.angular.x = 0.0;
	msg.angular.x = 0.0;

	std::string go_straight("GO STRAIGHT");
	std::string left_turn("LEFT TURN");
	std::string right_turn("RIGHT TURN");
	std::string go_faster("GO FASTER");
	std::string go_slower("GO SLOWER");
	std::string stop("STOP");

	while(ok()){
		ROS_INFO("Turtle heard: [%s]", command.c_str());
		if(!command.compare(go_straight)){
			msg.linear.x=0.5;
			msg.angular.z=0.0;
			command="";
		}else if(!command.compare(left_turn)){
			msg.angular.z=msg.angular.z+0.1;
			command="";
		}else if(!command.compare(right_turn)){
			msg.angular.z=msg.angular.z-0.1;
			command="";
		}else if(!command.compare(go_faster)){
			msg.linear.x=msg.linear.x+0.1;
			command="";
		}else if(!command.compare(go_slower)){
			msg.linear.x=msg.linear.x-0.1;
			command="";
		}else if(!command.compare(stop)){
			msg.linear.x = 0.0;
			msg.angular.z = 0.0;
			command="";
		}

		pub.publish(msg);
		ROS_INFO_STREAM("Printing turtle velocity command:"
				<<" linear="<<msg.linear.x
				<<" angular="<<msg.angular.z);
		spinOnce();
		rate.sleep();
	}
}
